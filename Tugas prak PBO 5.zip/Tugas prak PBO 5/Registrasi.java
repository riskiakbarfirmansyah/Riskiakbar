import java.util.regex.*;

// Interface untuk melakukan validasi pada kolom registrasi
interface RegistrationValidator {
    boolean isValid(String input);
}

// Implementasi untuk validasi username
class UsernameValidator implements RegistrationValidator {
    public boolean isValid(String input) {
        return !input.isEmpty();
    }
}

// Implementasi untuk validasi name
class NameValidator implements RegistrationValidator {
    public boolean isValid(String input) {
        return !input.isEmpty() && input.matches("[a-zA-Z ]+");
    }
}

// Implementasi untuk validasi phone number
class PhoneNumberValidator implements RegistrationValidator {
    public boolean isValid(String input) {
        return !input.isEmpty() && input.matches("[0-9]+");
    }
}

// Implementasi untuk validasi email
class EmailValidator implements RegistrationValidator {
    public boolean isValid(String input) {
        return !input.isEmpty() && input.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");
    }
}

// Implementasi untuk validasi password
class PasswordValidator implements RegistrationValidator {
    public boolean isValid(String input) {
        return input.length() >= 8;
    }
}

// Implementasi untuk registrasi melalui Google
class GoogleRegistration {
    public boolean register(String email) {
        return email.equals("pboa1@gmail.com");
    }
}

// Implementasi untuk registrasi melalui Facebook
class FacebookRegistration {
    public boolean register(String email) {
        return email.equals("pboa1@gmail.com");
    }
}

// Implementasi untuk registrasi melalui Apple
class AppleRegistration {
    public boolean register(String email) {
        return email.equals("pboa1@gmail.com");
    }
}

// Kelas utama untuk melakukan registrasi
class Registration {
    private RegistrationValidator usernameValidator;
    private RegistrationValidator nameValidator;
    private RegistrationValidator phoneNumberValidator;
    private RegistrationValidator emailValidator;
    private RegistrationValidator passwordValidator;

    public Registration() {
        usernameValidator = new UsernameValidator();
        nameValidator = new NameValidator();
        phoneNumberValidator = new PhoneNumberValidator();
        emailValidator = new EmailValidator();
        passwordValidator = new PasswordValidator();
    }

    public boolean registerAccount(String username, String name, String phoneNumber, String email, String password) {
        if (!usernameValidator.isValid(username)) {
            System.out.println("Username is required.");
            return false;
        }
        if (!nameValidator.isValid(name)) {
            System.out.println("Name is required and must only contain letters.");
            return false;
        }
        if (!phoneNumberValidator.isValid(phoneNumber)) {
            System.out.println("Phone number is required and must only contain numbers.");
            return false;
        }
        if (!emailValidator.isValid(email)) {
            System.out.println("Email is required and must be valid.");
            return false;
        }
        if (!passwordValidator.isValid(password)) {
            System.out.println("Password is required and must be at least 8 characters long.");
            return false;
        }

        // Registrasi akun
        System.out.println("Account registered successfully.");
        return true;
    }
}