public class Ulat extends Kupu{
    public void gerak(){
        System.out.println("Ulat merayap");
    }
}