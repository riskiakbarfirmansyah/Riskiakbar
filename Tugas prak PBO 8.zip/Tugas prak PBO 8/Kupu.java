public class Kupu{
    public void gerak(){

    }
}