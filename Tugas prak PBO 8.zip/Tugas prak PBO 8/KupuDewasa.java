public class KupuDewasa extends Kupu {
    public void gerak(){
        System.out.println("Kupu terbang");
    }
    
}