public class Mreg {
    public static void main(String[] args) {
        // Melakukan registrasi melalui formulir
        Registration registration = new Registration();
        registration.registerAccount("john_doe", "John Doe", "123456789", "john@example.com", "password123");

        // Melakukan registrasi melalui Google
        GoogleRegistration googleRegistration = new GoogleRegistration();
        System.out.println("Google registration status: " + googleRegistration.register("pboa1@gmail.com"));
    }
}
