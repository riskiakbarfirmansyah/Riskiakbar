public class Kepompong extends Kupu {
    public void gerak(){
        System.out.println("Kepompong diam");
    } 
}