public class Data<T> {
    T isi;

    public T getIsi(){
        return this.isi;
    }
    public void setIsi(T x) {
        this.isi= x;
    }
}