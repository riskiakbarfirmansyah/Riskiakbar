public class ObatTidakTersediaException extends Exception{
    public ObatTidakTersediaException(String message) {
        super(message);
    } 
}
