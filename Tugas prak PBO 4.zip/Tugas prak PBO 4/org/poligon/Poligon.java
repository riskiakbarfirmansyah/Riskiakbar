package org.poligon;

public class Poligon{
    protected int jumlahSisi;

    public int getJumlahSisi(){
        return this.jumlahSisi;
    }
}